// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#ifndef _STDAFX_H_
#define _STDAFX_H_

#include <afx.h>
#include <winsock.h>
#include <vector>

#endif 
