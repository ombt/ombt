// return codes
#ifndef __RETURNS_H
#define __RETURNS_H

#define OK 0
#define NOTOK -1
#define NOMATCH -2
#define PROMOTION -3
#define DUPLICATE -4

#endif
