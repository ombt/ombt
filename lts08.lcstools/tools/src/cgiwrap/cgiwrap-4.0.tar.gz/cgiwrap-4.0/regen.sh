#!/bin/sh

autoheader
autoconf

